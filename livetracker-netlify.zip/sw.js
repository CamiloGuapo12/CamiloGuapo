const CACHE = 'livetracker-v4';
const ASSETS = ['/', '/index.html', '/vendor/supabase.js', '/manifest.json'];

self.addEventListener('install', e => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)));
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(caches.keys().then(keys =>
    Promise.all(keys.filter(k => k !== CACHE).map(k => caches.delete(k)))
  ));
  self.clients.claim();
});

self.addEventListener('fetch', e => {
  if (e.request.method !== 'GET') return;
  // Network first for API calls, cache first for assets
  if (e.request.url.includes('supabase') || e.request.url.includes('api.anthropic') || e.request.url.includes('open.er-api') || e.request.url.includes('generativelanguage') || e.request.url.includes('allorigins') || new URL(e.request.url).origin !== self.location.origin) {
    return; // always network for API
  }
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request).then(res => {
      const clone = res.clone();
      caches.open(CACHE).then(c => c.put(e.request, clone));
      return res;
    }))
  );
});
